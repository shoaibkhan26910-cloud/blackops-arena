export type Tournament={id:string;title:string;game:'BGMI'|'Free Fire';mode:string;prize:number;entry:number;teams:number;maxTeams:number;status:'LIVE'|'UPCOMING'|'COMPLETED';date:string};
